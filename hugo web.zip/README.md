# javaswag.github.io

https://javaswag.github.io

To run:

```
brew install hugo

sh buils.sh

sh preview.sh
```